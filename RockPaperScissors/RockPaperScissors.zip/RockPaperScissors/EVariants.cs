﻿namespace RockPaper
{
    public enum EVariants
    {
        Rock, 
        Paper, 
        Scissors,
        Nan
    }
}
